let database = window.localStorage.getItem('database')
if(!database) database = []
else database = JSON.parse(database)

