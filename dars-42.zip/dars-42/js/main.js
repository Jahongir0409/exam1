let tBody = document.querySelector('tbody')
let form = document.querySelector('form')

function renderer (data) {
	tBody.innerHTML = null
	data = mySort(data, filterSelect.value)
	for (let i in data) {
		let tr = document.createElement('tr')
		let tdIndex = document.createElement('td')
		let tdName = document.createElement('td')
		let tdAge = document.createElement('td')
		let tdScore = document.createElement('td')
		
		tdIndex.textContent = i - 0 + 1
		tdName.textContent = data[i].name
		tdAge.textContent = data[i].age
		tdScore.textContent = data[i].score
		
		tr.appendChild(tdIndex)
		tr.appendChild(tdName)
		tr.appendChild(tdAge)
		tr.appendChild(tdScore)
		
		tBody.appendChild(tr)
	}
}

renderer(database)

filterSelect.addEventListener('change', () => renderer(database) )

form.addEventListener('submit', (hodisa) => {
	event.preventDefault()
	if(scoreInput.value - 0 >= 1 && scoreInput.value - 0 <= 100) {
		let obj = {
			name: nameInput.value,
			age: ageInput.value,
			score: scoreInput.value
		}
		database.push(obj)
		renderer(database)
		window.localStorage.setItem('database', JSON.stringify(database))	
		nameInput.value = null
		ageInput.value = null
		scoreInput.value = null
	} else {
		scoreInput.value = null
		scoreInput.style.borderColor = 'red'
		scoreInput.placeholder = "1 dan katta 100 dan kichik"
	}
})



function mySort (array, instuction) {
	let sorted
	if(instuction === "age") {
		sorted = array.sort(function(a, b) {
		  return a.age - b.age
		})
	}
	else if(instuction === "score") {
		sorted = array.sort(function(a, b) {
		  return a.score - b.score
		})
	}
	else if(instuction === "name") {
		sorted = array.sort(function(a, b) {
			return a.name.toLowerCase() > b.name.toLowerCase() ? 1 : -1
		})
	}
	return sorted
}




// cookies        // DOM - x // server orqali malumot yoziladi  4096 byte
// localStorage   // Server - x // DOM malumot yoza oladi       5 MB
// sessionStorage // Server - x // DOM malumot yoza oladi       5 MB




